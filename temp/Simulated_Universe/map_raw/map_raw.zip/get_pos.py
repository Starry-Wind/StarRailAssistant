#!/usr/bin/env python3
# -*- coding:utf-8 -*-
import cv2
import numpy as np
from matplotlib import pyplot as plt

def get_pos(event,x,y,flags,param):
    if event==cv2.EVENT_LBUTTONDOWN:
        print((x,y))

num = input("请输入地图编号:")
image=cv2.imread(f".//{num}.png")
cv2.imshow('image',image)
cv2.setMouseCallback("image",get_pos)
cv2.waitKey(0)