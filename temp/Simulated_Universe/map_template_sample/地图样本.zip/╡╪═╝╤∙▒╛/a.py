import cv2
import numpy as np
import time
from PIL import ImageGrab
import os


def capture_screen_area(x, y, w, h, output_directory):
    count = 0
    while True:

        img = np.array(ImageGrab.grab(bbox=(x, y, x+w, y+h)))

        img_bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

        # 生成唯一的文件名
        timestamp = int(time.time())
        filename = f"{output_directory}/screenshot_{timestamp}_{count}.png"

        # 保存图像到文件
        cv2.imwrite(filename, img_bgr)
        count += 1
        # 等待1秒钟
        time.sleep(1)


# 定义截图区域的左上角坐标和宽高
x = 47  # 左上角横坐标
y = 58  # 左上角纵坐标
w = 187  # 区域宽度
h = 187  # 区域高度

# 定义保存截图的目录
output_directory = "screenshots"


os.makedirs(output_directory, exist_ok=True)


capture_screen_area(x, y, w, h, output_directory)
